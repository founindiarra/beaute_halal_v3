<template>
  <section class="nf">
    <div class="container inner">
      <p class="numeral big" aria-hidden="true">404</p>
      <h1>Cette page s’est <em>défaite</em>.</h1>
      <p class="lede">L’adresse demandée n’existe pas ou n’existe plus. Revenez à l’accueil ou demandez directement un rendez-vous.</p>
      <div class="cta">
        <RouterLink :to="{ name: 'home' }" class="btn btn-primary">Retour à l’accueil</RouterLink>
        <RouterLink :to="{ name: 'booking' }" class="link-arrow">Demander un rendez-vous <span class="arrow" aria-hidden="true">→</span></RouterLink>
      </div>
    </div>
  </section>
</template>

<style scoped>
.nf { padding-block: clamp(4rem, 12vw, 9rem); }
.inner { display: grid; gap: 1.5rem; }
.big { font-size: clamp(5rem, 22vw, 14rem); line-height: 0.85; }
h1 { font-size: clamp(2.2rem, 6vw, 4rem); max-width: 14ch; }
.cta { display: flex; flex-wrap: wrap; align-items: center; gap: 1rem 2rem; }
</style>
