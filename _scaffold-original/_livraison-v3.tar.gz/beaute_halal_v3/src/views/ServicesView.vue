<script setup>
import { computed } from 'vue'

import ServiceRows from '@/components/services/ServiceRows.vue'
import VisitBlock from '@/components/sections/VisitBlock.vue'
import DataState from '@/components/ui/DataState.vue'
import PageIntro from '@/components/ui/PageIntro.vue'
import { useApiData } from '@/composables/useApiData'
import { fetchServiceCategories, fetchServices } from '@/services/api'

const load = async () => {
  const [categories, services] = await Promise.all([fetchServiceCategories(), fetchServices()])
  return { categories, services }
}
const { data, loading, error, reload } = useApiData(load, { categories: [], services: [] })

/** Regroupe par catégorie ; les prestations sans catégorie connue restent visibles. */
const groups = computed(() => {
  const { categories, services } = data.value
  const known = new Set(categories.map((c) => c.slug))
  const list = categories
    .map((c) => ({ key: c.slug, name: c.name, items: services.filter((s) => s.category?.slug === c.slug) }))
    .filter((g) => g.items.length)
  const others = services.filter((s) => !s.category?.slug || !known.has(s.category.slug))
  if (others.length) list.push({ key: 'autres', name: 'Autres prestations', items: others })
  let n = 1
  return list.map((g) => {
    const start = n
    n += g.items.length
    return { ...g, start }
  })
})
</script>

<template>
  <div>
    <PageIntro
      eyebrow="Prestations"
      title="Chaque étape de la vie de vos locks."
      lede="Durées et tarifs sont ceux enregistrés par le salon. Choisissez une prestation pour ouvrir directement le choix de la date."
    >
      <template #title>Chaque étape de la vie de <em>vos locks</em>.</template>
    </PageIntro>

    <nav v-if="groups.length > 1" class="jump" aria-label="Catégories de prestations">
      <ul class="container">
        <li v-for="g in groups" :key="g.key"><a :href="`#${g.key}`">{{ g.name }}</a></li>
      </ul>
    </nav>

    <section class="section-tight">
      <div class="container">
        <DataState
          :loading="loading"
          :error="error"
          :empty="!groups.length"
          loading-label="Chargement des prestations…"
          empty-label="Aucune prestation n’est disponible pour le moment."
          min-height="24rem"
          @retry="reload"
        >
          <section v-for="g in groups" :id="g.key" :key="g.key" class="group">
            <h2 class="group-title">{{ g.name }}</h2>
            <ServiceRows :services="g.items" :start="g.start" />
          </section>
        </DataState>
      </div>
    </section>

    <VisitBlock />
  </div>
</template>

<style scoped>
.jump { border-bottom: 1px solid var(--line); background: var(--bone); }
.jump ul { display: flex; gap: 0.5rem 1.5rem; overflow-x: auto; padding-block: 0.4rem; scrollbar-width: none; }
.jump a { display: inline-flex; align-items: center; min-height: 44px; white-space: nowrap; font-weight: 600; font-size: 0.92rem; text-decoration: none; color: var(--muted); }
.jump a:hover { color: var(--copper); }
.group { padding-block: 2.5rem 1.5rem; }
.group-title { font-size: clamp(1.7rem, 3.6vw, 2.5rem); margin-bottom: 1.5rem; }
</style>
