<script setup>
import ProcessSection from '@/components/sections/ProcessSection.vue'
import TeamSection from '@/components/sections/TeamSection.vue'
import VisitBlock from '@/components/sections/VisitBlock.vue'
import PageIntro from '@/components/ui/PageIntro.vue'
import { useSalon } from '@/composables/useSalon'
import { values } from '@/data/editorial'

const { salon } = useSalon()
</script>

<template>
  <div>
    <PageIntro
      eyebrow="À propos"
      title="Un salon entièrement tourné vers les locks."
      :lede="salon.shortDescription || 'Beauté Halal est un salon spécialisé dans les locks : de la création à l’entretien et aux soins.'"
    >
      <template #title>Un salon entièrement tourné vers les <em>locks</em>.</template>
    </PageIntro>

    <section class="section on-paper">
      <div class="container grid">
        <div v-reveal>
          <p class="eyebrow">Notre approche</p>
          <h2>Trois principes, <em>sans fioritures</em>.</h2>
        </div>
        <ol class="values">
          <li v-for="(v, i) in values" :key="v.title" v-reveal="i * 90">
            <span class="numeral">0{{ i + 1 }}</span>
            <div>
              <h3>{{ v.title }}</h3>
              <p>{{ v.text }}</p>
            </div>
          </li>
        </ol>
      </div>
    </section>

    <TeamSection />
    <ProcessSection />
    <VisitBlock />
  </div>
</template>

<style scoped>
.grid { display: grid; gap: 2.5rem; }
.grid > div:first-child { display: grid; gap: 1rem; align-content: start; }
.values { display: grid; border-top: 1px solid var(--line-strong); }
.values li { display: grid; grid-template-columns: 4rem 1fr; gap: 1rem; padding-block: 1.8rem; border-bottom: 1px solid var(--line-strong); }
.values .numeral { font-size: 2.4rem; }
.values p { color: var(--muted); margin-top: 0.4rem; }
@media (min-width: 900px) { .grid { grid-template-columns: 1fr 1.2fr; gap: 6rem; } }
</style>
