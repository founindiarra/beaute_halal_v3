<script setup>
import Wordmark from '@/components/ui/Wordmark.vue'
import { useSalon } from '@/composables/useSalon'

const { salon, hours, hasWhatsapp, whatsappLink } = useSalon()
const year = new Date().getFullYear()

const nav = [
  { name: 'services', label: 'Prestations' },
  { name: 'gallery', label: 'Coiffures' },
  { name: 'about', label: 'À propos' },
  { name: 'faq', label: 'Questions fréquentes' },
  { name: 'contact', label: 'Contact' },
  { name: 'booking', label: 'Demander un rendez-vous' },
]
</script>

<template>
  <footer class="footer on-dark">
    <div class="container grid">
      <div class="col-brand">
        <RouterLink :to="{ name: 'home' }" class="brand" aria-label="Beauté Halal — accueil"><Wordmark /></RouterLink>
        <p v-if="salon.tagline || salon.shortDescription" class="blurb">{{ salon.tagline || salon.shortDescription }}</p>
        <ul v-if="salon.socials?.length" class="socials" aria-label="Réseaux sociaux">
          <li v-for="s in salon.socials" :key="s.id || s.url">
            <a :href="s.url" target="_blank" rel="noopener noreferrer">{{ s.label || s.id }}<span class="sr-only"> (nouvel onglet)</span></a>
          </li>
        </ul>
      </div>

      <nav class="col" aria-label="Pied de page">
        <h2 class="h">Naviguer</h2>
        <ul>
          <li v-for="l in nav" :key="l.name"><RouterLink :to="{ name: l.name }">{{ l.label }}</RouterLink></li>
        </ul>
      </nav>

      <div class="col">
        <h2 class="h">Nous joindre</h2>
        <ul>
          <li v-if="salon.address.city">
            <address>
              <template v-if="salon.address.line1">{{ salon.address.line1 }}<br /></template>
              <template v-if="salon.address.line2">{{ salon.address.line2 }}<br /></template>
              {{ salon.address.city }}<template v-if="salon.address.country">, {{ salon.address.country }}</template>
            </address>
          </li>
          <li v-if="salon.phone.display"><a :href="salon.phone.href || `tel:${salon.phone.display.replace(/\s/g, '')}`">{{ salon.phone.display }}</a></li>
          <li v-if="hasWhatsapp"><a :href="whatsappLink()" target="_blank" rel="noopener noreferrer">WhatsApp<span class="sr-only"> (nouvel onglet)</span></a></li>
          <li v-if="salon.email"><a :href="`mailto:${salon.email}`">{{ salon.email }}</a></li>
          <li v-if="!salon.address.city && !salon.phone.display && !hasWhatsapp && !salon.email">
            <RouterLink :to="{ name: 'contact' }">Page contact</RouterLink>
          </li>
        </ul>
      </div>

      <div v-if="hours.length" class="col">
        <h2 class="h">Horaires</h2>
        <dl class="hours">
          <div v-for="h in hours" :key="h.day" :class="{ closed: h.isClosed }">
            <dt>{{ h.day }}</dt>
            <dd>{{ h.value }}</dd>
          </div>
        </dl>
      </div>
    </div>

    <div class="container legal">
      <p>© {{ year }} Beauté Halal. Tous droits réservés.</p>
    </div>
  </footer>
</template>

<style scoped>
.footer { padding-top: clamp(3.5rem, 7vw, 6rem); }
.grid { display: grid; gap: 2.75rem 2rem; grid-template-columns: 1fr; padding-bottom: 3.5rem; }
.brand { display: inline-block; text-decoration: none; margin-bottom: 1.25rem; }
.blurb { color: var(--on-dark-muted); max-width: 26rem; }
.socials { display: flex; flex-wrap: wrap; gap: 0.25rem 1.25rem; margin-top: 1.25rem; }
.h { font-family: var(--font-body); font-size: 0.74rem; font-weight: 700; letter-spacing: 0.2em; text-transform: uppercase; color: var(--caramel); margin-bottom: 1rem; line-height: 1.2; }
.col ul { display: flex; flex-direction: column; gap: 0.15rem; }
.col a, .socials a { display: inline-flex; align-items: center; min-height: 40px; text-decoration: none; color: var(--ivory); }
.col a:hover, .socials a:hover { color: var(--caramel); text-decoration: underline; text-underline-offset: 4px; }
address { font-style: normal; color: var(--on-dark-muted); padding-block: 0.4rem; }
.hours > div { display: flex; justify-content: space-between; gap: 1rem; padding: 0.45rem 0; border-bottom: 1px solid rgba(245, 238, 225, 0.12); font-size: 0.95rem; }
.hours dt { color: var(--on-dark-muted); }
.hours dd { margin: 0; text-align: right; }
.hours .closed dd { color: var(--on-dark-muted); }
.legal { border-top: 1px solid rgba(245, 238, 225, 0.14); padding-block: 1.4rem 1.8rem; color: var(--on-dark-muted); font-size: 0.88rem; }

@media (min-width: 720px) { .grid { grid-template-columns: 1fr 1fr; } .col-brand { grid-column: 1 / -1; } }
@media (min-width: 1024px) { .grid { grid-template-columns: 1.5fr 1fr 1.1fr 1.1fr; } .col-brand { grid-column: auto; } }
</style>
