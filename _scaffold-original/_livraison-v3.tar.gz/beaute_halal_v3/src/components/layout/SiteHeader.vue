<script setup>
import { nextTick, onBeforeUnmount, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

import Wordmark from '@/components/ui/Wordmark.vue'
import { pad2 } from '@/utils/format'

const links = [
  { name: 'services', label: 'Prestations' },
  { name: 'gallery', label: 'Coiffures' },
  { name: 'about', label: 'À propos' },
  { name: 'faq', label: 'Questions' },
  { name: 'contact', label: 'Contact' },
]

const route = useRoute()
const open = ref(false)
const panel = ref(null)
const toggle = ref(null)
const closeBtn = ref(null)

const setLock = (on) => {
  document.documentElement.style.overflow = on ? 'hidden' : ''
}

const close = (restoreFocus = true) => {
  open.value = false
  if (restoreFocus) nextTick(() => toggle.value?.focus())
}

watch(open, async (isOpen) => {
  setLock(isOpen)
  if (isOpen) {
    await nextTick()
    closeBtn.value?.focus()
  }
})
watch(
  () => route.fullPath,
  () => {
    if (open.value) close(false)
  },
)
onBeforeUnmount(() => setLock(false))

/** Échap ferme ; Tab reste dans le panneau tant qu'il est ouvert. */
const onKeydown = (e) => {
  if (!open.value) return
  if (e.key === 'Escape') {
    close()
    return
  }
  if (e.key !== 'Tab' || !panel.value) return
  const items = [...panel.value.querySelectorAll('a[href], button:not([disabled])')]
  if (!items.length) return
  const first = items[0]
  const last = items[items.length - 1]
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault()
    last.focus()
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault()
    first.focus()
  }
}
</script>

<template>
  <header class="site-header" @keydown="onKeydown">
    <div class="container bar">
      <RouterLink :to="{ name: 'home' }" class="brand" aria-label="Beauté Halal — accueil">
        <Wordmark />
      </RouterLink>

      <nav class="nav-desktop" aria-label="Navigation principale">
        <RouterLink v-for="l in links" :key="l.name" :to="{ name: l.name }" class="nav-link">{{ l.label }}</RouterLink>
      </nav>

      <div class="actions">
        <RouterLink :to="{ name: 'booking' }" class="btn btn-primary btn-sm cta-desktop">Demander un rendez-vous</RouterLink>
        <button
          ref="toggle"
          type="button"
          class="menu-btn"
          :aria-expanded="open"
          aria-controls="mobile-menu"
          @click="open = true"
        >
          <span class="menu-label">Menu</span>
          <span class="menu-bars" aria-hidden="true"><i /><i /></span>
        </button>
      </div>
    </div>

    <Transition name="menu">
      <div v-if="open" id="mobile-menu" ref="panel" class="mobile on-dark" role="dialog" aria-modal="true" aria-label="Menu">
        <div class="container mobile-top">
          <Wordmark compact />
          <button ref="closeBtn" type="button" class="menu-btn" @click="close()">
            <span class="menu-label">Fermer</span>
            <span class="menu-bars is-x" aria-hidden="true"><i /><i /></span>
          </button>
        </div>
        <nav class="container mobile-nav" aria-label="Navigation principale (mobile)">
          <RouterLink v-for="(l, i) in links" :key="l.name" :to="{ name: l.name }" class="mobile-link">
            <span class="numeral">{{ pad2(i + 1) }}</span>
            <span>{{ l.label }}</span>
          </RouterLink>
        </nav>
        <div class="container mobile-foot">
          <RouterLink :to="{ name: 'booking' }" class="btn btn-primary btn-block">Demander un rendez-vous</RouterLink>
        </div>
      </div>
    </Transition>
  </header>
</template>

<style scoped>
.site-header { position: sticky; top: 0; z-index: 100; background: color-mix(in srgb, var(--ivory) 94%, transparent); backdrop-filter: blur(8px); border-bottom: 1px solid var(--line); }
.bar { height: var(--header-h); display: flex; align-items: center; justify-content: space-between; gap: 1.5rem; }
.brand { text-decoration: none; display: inline-flex; min-height: 44px; align-items: center; }
.nav-desktop { display: none; gap: 0.25rem; margin-left: auto; }
.nav-link { position: relative; display: inline-flex; align-items: center; min-height: 44px; padding: 0 0.9rem; font-weight: 500; font-size: 0.97rem; text-decoration: none; color: var(--ink); }
.nav-link::after { content: ''; position: absolute; left: 0.9rem; right: 0.9rem; bottom: 8px; height: 1.5px; background: var(--copper); transform: scaleX(0); transform-origin: left; transition: transform 0.35s var(--ease); }
.nav-link:hover::after, .nav-link.router-link-active::after { transform: scaleX(1); }
.actions { display: flex; align-items: center; gap: 0.75rem; }
.cta-desktop { display: none; }
.menu-btn { display: inline-flex; align-items: center; gap: 0.7rem; min-height: 44px; padding: 0 0.25rem; background: none; border: 0; cursor: pointer; font-weight: 600; font-size: 0.82rem; letter-spacing: 0.16em; text-transform: uppercase; }
.menu-bars { position: relative; width: 26px; height: 12px; }
.menu-bars i { position: absolute; left: 0; width: 100%; height: 1.5px; background: currentColor; transition: transform 0.3s var(--ease); }
.menu-bars i:first-child { top: 0; }
.menu-bars i:last-child { bottom: 0; }
.menu-bars.is-x i:first-child { top: 5px; transform: rotate(45deg); }
.menu-bars.is-x i:last-child { bottom: 5px; transform: rotate(-45deg); }

.mobile { position: fixed; inset: 0; z-index: 150; display: flex; flex-direction: column; overflow-y: auto; }
.mobile-top { height: var(--header-h); display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(245, 238, 225, 0.14); }
.mobile-top .menu-btn { color: var(--ivory); }
.mobile-nav { display: flex; flex-direction: column; padding-block: 1.5rem; flex: 1; }
.mobile-link { display: flex; align-items: baseline; gap: 1.2rem; padding: 0.9rem 0; min-height: 56px; border-bottom: 1px solid rgba(245, 238, 225, 0.12); font-family: var(--font-display); font-size: clamp(1.9rem, 8vw, 2.6rem); text-decoration: none; color: var(--ivory); letter-spacing: -0.02em; }
.mobile-link .numeral { font-size: 0.95rem; font-family: var(--font-body); font-weight: 600; letter-spacing: 0.1em; color: var(--caramel); }
.mobile-link.router-link-active { color: var(--caramel); }
.mobile-foot { padding-block: 1.25rem 2rem; }

.menu-enter-active, .menu-leave-active { transition: opacity 0.3s var(--ease), transform 0.3s var(--ease); }
.menu-enter-from, .menu-leave-to { opacity: 0; transform: translateY(-12px); }

@media (min-width: 1024px) {
  .nav-desktop { display: flex; }
  .cta-desktop { display: inline-flex; }
  .menu-btn { display: none; }
}
@media (min-width: 1024px) and (max-width: 1180px) {
  .nav-link { padding: 0 0.6rem; }
}
</style>
