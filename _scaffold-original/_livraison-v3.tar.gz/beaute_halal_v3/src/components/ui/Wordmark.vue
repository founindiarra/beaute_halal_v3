<script setup>
defineProps({ compact: { type: Boolean, default: false } })
</script>

<template>
  <span class="wordmark">
    <svg class="wordmark-glyph" viewBox="0 0 40 40" aria-hidden="true" focusable="false">
      <path d="M20 3c-7 5-7 11 0 16s7 11 0 18" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" />
      <path d="M14 6c7 5 7 11 0 16s-7 10 0 15" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" opacity=".55" />
    </svg>
    <span class="wordmark-text">
      <span class="wordmark-name">Beauté Halal</span>
      <span v-if="!compact" class="wordmark-sub">Atelier de locks</span>
    </span>
  </span>
</template>

<style scoped>
.wordmark { display: inline-flex; align-items: center; gap: 0.7rem; color: var(--ink); }
.wordmark-glyph { width: 30px; height: 30px; color: var(--copper); flex: none; }
.wordmark-text { display: flex; flex-direction: column; line-height: 1; }
.wordmark-name { font-family: var(--font-display); font-size: 1.45rem; font-weight: 500; letter-spacing: -0.02em; font-variation-settings: 'opsz' 48; }
.wordmark-sub { margin-top: 0.3rem; font-size: 0.64rem; font-weight: 600; letter-spacing: 0.24em; text-transform: uppercase; color: var(--muted); }
:global(.on-dark) .wordmark { color: var(--ivory); }
:global(.on-dark) .wordmark-glyph { color: var(--caramel); }
:global(.on-dark) .wordmark-sub { color: var(--on-dark-muted); }
</style>
