<script setup>
import { computed } from 'vue'

import ServiceRows from '@/components/services/ServiceRows.vue'
import DataState from '@/components/ui/DataState.vue'
import { useApiData } from '@/composables/useApiData'
import { fetchServices } from '@/services/api'

/** Prestations mises en avant ; à défaut, les premières du catalogue. */
const load = async () => {
  const featured = await fetchServices({ featured: true })
  if (featured.length) return featured
  return (await fetchServices()).slice(0, 5)
}
const { data, loading, error, reload } = useApiData(load, [])
const services = computed(() => data.value ?? [])
</script>

<template>
  <section class="section">
    <div class="container">
      <header class="head" v-reveal>
        <div>
          <p class="eyebrow">Prestations</p>
          <h2>Ce que nous <em>réalisons</em></h2>
        </div>
        <RouterLink :to="{ name: 'services' }" class="link-arrow">Toutes les prestations <span class="arrow" aria-hidden="true">→</span></RouterLink>
      </header>
      <DataState
        :loading="loading"
        :error="error"
        :empty="!services.length"
        loading-label="Chargement des prestations…"
        empty-label="Les prestations seront bientôt en ligne."
        @retry="reload"
      >
        <ServiceRows :services="services" />
      </DataState>
    </div>
  </section>
</template>

<style scoped>
.head { display: flex; flex-wrap: wrap; align-items: end; justify-content: space-between; gap: 1.5rem; margin-bottom: 2.5rem; }
.head > div { display: grid; gap: 1rem; }
</style>
