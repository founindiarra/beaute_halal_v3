<script setup>
import { computed } from 'vue'

import ApiImage from '@/components/ui/ApiImage.vue'
import { useApiData } from '@/composables/useApiData'
import { useSalon } from '@/composables/useSalon'
import { fetchGalleryItems } from '@/services/api'

const { salon, loaded } = useSalon()

/* Les photos viennent de la galerie du salon (coiffures « mises en avant »).
   Si l'API ne répond pas, le hero reste typographique : jamais de photo inventée. */
const { data: featured } = useApiData(() => fetchGalleryItems({ featured: true }), [])
const photos = computed(() => (featured.value ?? []).filter((p) => p.imageUrl).slice(0, 2))

const lede = computed(
  () =>
    salon.value.shortDescription ||
    'Salon spécialisé dans les locks. Choisissez votre prestation, un créneau disponible, et envoyez votre demande en quelques minutes.',
)
</script>

<template>
  <section class="hero">
    <div class="container grid">
      <div class="copy">
        <p class="eyebrow">Salon spécialisé dans les locks</p>
        <h1>Vos locks, <em>de la création</em> à l’entretien.</h1>
        <p class="lede">{{ lede }}</p>
        <div class="cta">
          <RouterLink :to="{ name: 'booking' }" class="btn btn-primary">Demander un rendez-vous</RouterLink>
          <RouterLink :to="{ name: 'services' }" class="link-arrow">Voir les prestations <span class="arrow" aria-hidden="true">→</span></RouterLink>
        </div>
        <p v-if="loaded && salon.bookingWindowDays" class="note">
          Créneaux ouverts sur les {{ salon.bookingWindowDays }} prochains jours, mis à jour en direct.
        </p>
      </div>

      <div class="art" aria-hidden="false">
        <div class="arch main">
          <ApiImage v-if="photos[0]" :src="photos[0].imageUrl" :alt="photos[0].title" ratio="3 / 4.2" eager />
          <div v-else class="motif" role="presentation">
            <svg viewBox="0 0 120 200" aria-hidden="true">
              <path d="M60 6c-34 22-34 48 0 70s34 48 0 70-34 36 0 48" fill="none" stroke="#c9965b" stroke-width="9" stroke-linecap="round" />
              <path d="M34 20c34 22 34 48 0 70s-34 48 0 70" fill="none" stroke="#f5eee1" stroke-width="3.5" stroke-linecap="round" opacity=".55" />
            </svg>
          </div>
        </div>
        <div v-if="photos[1]" class="inset">
          <ApiImage :src="photos[1].imageUrl" :alt="photos[1].title" ratio="1 / 1.15" eager />
        </div>
        <span class="stamp" aria-hidden="true">Locks<br />· Soins ·<br />Entretien</span>
      </div>
    </div>
  </section>
</template>

<style scoped>
.hero { padding-block: clamp(2.5rem, 6vw, 5.5rem) clamp(3rem, 7vw, 6rem); overflow: hidden; }
.grid { display: grid; gap: 3.5rem; align-items: center; }
.copy { display: grid; gap: 1.6rem; align-content: start; }
.cta { display: flex; flex-wrap: wrap; align-items: center; gap: 1.1rem 1.8rem; margin-top: 0.4rem; }
.note { font-size: 0.9rem; color: var(--muted); }

.art { position: relative; width: min(100%, 440px); justify-self: center; padding-bottom: 2rem; }
.arch { border-radius: 999px 999px 4px 4px; overflow: hidden; background: var(--ink); box-shadow: 14px 14px 0 var(--paper); }
.motif { aspect-ratio: 3 / 4.2; display: grid; place-items: center; background: radial-gradient(circle at 50% 30%, var(--umber), var(--ink) 70%); }
.motif svg { width: 46%; height: auto; }
.inset { position: absolute; width: 38%; right: -4%; bottom: 0; border: 6px solid var(--ivory); border-radius: 4px; overflow: hidden; box-shadow: 0 18px 30px -18px rgba(38, 24, 15, 0.5); }
.stamp { position: absolute; left: -1rem; bottom: 4rem; display: grid; place-items: center; width: 6.2rem; height: 6.2rem; border-radius: 50%; background: var(--olive); color: var(--ivory); font-size: 0.66rem; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; text-align: center; line-height: 1.5; transform: rotate(-10deg); }

@media (min-width: 900px) {
  .grid { grid-template-columns: 1.25fr 1fr; gap: 4rem; }
  .art { justify-self: end; }
}
@media (max-width: 420px) {
  .stamp { left: -0.4rem; width: 5.2rem; height: 5.2rem; font-size: 0.58rem; }
}
</style>
