<script setup>
import { computed } from 'vue'
import { useRouter } from 'vue-router'

import ApiImage from '@/components/ui/ApiImage.vue'
import DataState from '@/components/ui/DataState.vue'
import { useApiData } from '@/composables/useApiData'
import { fetchGalleryItems } from '@/services/api'

const router = useRouter()
const { data, loading, error, reload } = useApiData(async () => {
  const featured = await fetchGalleryItems({ featured: true })
  return featured.length >= 3 ? featured : await fetchGalleryItems()
}, [])
const items = computed(() => (data.value ?? []).filter((i) => i.imageUrl).slice(0, 5))
/* Cadrages alternés : composition asymétrique, jamais une grille de cartes identiques. */
const ratios = ['4 / 5.4', '1 / 1', '4 / 4.6', '4 / 5', '1 / 1.1']
const open = (item) => router.push({ name: 'gallery', query: { photo: item.id } })
</script>

<template>
  <section class="section on-dark">
    <div class="container">
      <header class="head" v-reveal>
        <div>
          <p class="eyebrow">Coiffures</p>
          <h2>Des réalisations, <em>pas des promesses</em></h2>
        </div>
        <RouterLink :to="{ name: 'gallery' }" class="link-arrow">Voir toutes les coiffures <span class="arrow" aria-hidden="true">→</span></RouterLink>
      </header>
      <DataState :loading="loading" :error="error" :empty="!items.length" loading-label="Chargement des coiffures…" empty-label="Les photos seront bientôt en ligne." @retry="reload">
        <ul class="strip">
          <li v-for="(item, i) in items" :key="item.id" v-reveal="i * 70" :class="`c${i}`">
            <button type="button" :aria-label="`Voir la coiffure : ${item.title}`" @click="open(item)">
              <ApiImage :src="item.imageUrl" :alt="item.title" :ratio="ratios[i % ratios.length]" />
              <span class="cap">{{ item.title }}</span>
            </button>
          </li>
        </ul>
      </DataState>
    </div>
  </section>
</template>

<style scoped>
.head { display: flex; flex-wrap: wrap; align-items: end; justify-content: space-between; gap: 1.5rem; margin-bottom: 2.5rem; }
.head > div { display: grid; gap: 1rem; }
.strip { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0.75rem; align-items: start; }
.strip button { display: block; width: 100%; padding: 0; border: 0; background: none; cursor: pointer; text-align: left; border-radius: var(--radius); overflow: hidden; position: relative; }
.strip :deep(img) { transition: transform 0.8s var(--ease); }
.strip button:hover :deep(img) { transform: scale(1.04); }
.cap { position: absolute; left: 0; right: 0; bottom: 0; padding: 2.5rem 0.9rem 0.8rem; font-size: 0.9rem; color: var(--ivory); background: linear-gradient(transparent, rgba(38, 24, 15, 0.85)); }
.c0 { grid-column: span 2; }
@media (min-width: 900px) {
  .strip { grid-template-columns: repeat(12, 1fr); gap: 1.1rem; }
  .c0 { grid-column: span 5; }
  .c1 { grid-column: span 4; margin-top: 3rem; }
  .c2 { grid-column: span 3; }
  .c3 { grid-column: 3 / span 4; margin-top: 1rem; }
  .c4 { grid-column: span 4; }
}
</style>
