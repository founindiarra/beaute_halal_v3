<script setup>
import { useSalon } from '@/composables/useSalon'

defineProps({
  title: { type: String, default: 'Prêt(e) pour de beaux locks ?' },
  text: { type: String, default: 'Choisissez votre prestation et un créneau disponible. Le salon vous confirme ensuite votre rendez-vous.' },
})

const { salon, hours, hasWhatsapp, whatsappLink } = useSalon()
</script>

<template>
  <section class="visit on-dark section">
    <div class="container grid">
      <div class="lead" v-reveal>
        <p class="eyebrow">Rendez-vous</p>
        <h2>{{ title }}</h2>
        <p class="lede">{{ text }}</p>
        <div class="cta">
          <RouterLink :to="{ name: 'booking' }" class="btn btn-primary">Demander un rendez-vous</RouterLink>
          <a v-if="hasWhatsapp" :href="whatsappLink()" class="btn btn-outline" target="_blank" rel="noopener noreferrer">
            Écrire sur WhatsApp<span class="sr-only"> (nouvel onglet)</span>
          </a>
        </div>
      </div>

      <div v-if="hours.length || salon.address.city || salon.phone.display" class="info" v-reveal="120">
        <dl v-if="hours.length" class="hours">
          <div v-for="h in hours" :key="h.day">
            <dt>{{ h.day }}</dt>
            <dd :class="{ off: h.isClosed }">{{ h.value }}</dd>
          </div>
        </dl>
        <address v-if="salon.address.city">
          {{ [salon.address.line1, salon.address.line2].filter(Boolean).join(', ') }}<br v-if="salon.address.line1 || salon.address.line2" />
          {{ salon.address.city }}
        </address>
        <a v-if="salon.phone.display" class="tel" :href="salon.phone.href || `tel:${salon.phone.display.replace(/\s/g, '')}`">{{ salon.phone.display }}</a>
      </div>
    </div>
  </section>
</template>

<style scoped>
.grid { display: grid; gap: 3rem; }
.lead { display: grid; gap: 1.4rem; align-content: start; }
.cta { display: flex; flex-wrap: wrap; gap: 0.9rem; margin-top: 0.5rem; }
.info { display: grid; gap: 1.5rem; align-content: start; }
.hours > div { display: flex; justify-content: space-between; gap: 1rem; padding: 0.7rem 0; border-bottom: 1px solid rgba(245, 238, 225, 0.16); }
.hours dt { color: var(--on-dark-muted); }
.hours dd { margin: 0; text-align: right; }
.hours dd.off { color: var(--on-dark-muted); }
address { font-style: normal; color: var(--on-dark-muted); }
.tel { font-family: var(--font-display); font-size: 1.7rem; text-decoration: none; color: var(--caramel); width: fit-content; }
@media (min-width: 900px) { .grid { grid-template-columns: 1.3fr 1fr; gap: 5rem; } }
</style>
