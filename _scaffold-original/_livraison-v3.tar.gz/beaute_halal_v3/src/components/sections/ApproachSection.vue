<script setup>
import { values } from '@/data/editorial'
import { useSalon } from '@/composables/useSalon'

const { salon } = useSalon()
</script>

<template>
  <section class="approach on-paper section">
    <div class="container grid">
      <div v-reveal class="statement">
        <p class="eyebrow">Le savoir-faire</p>
        <h2>Une affaire de <em>geste</em>, de tension et de régularité.</h2>
        <p v-if="salon.tagline" class="lede">{{ salon.tagline }}</p>
        <RouterLink :to="{ name: 'about' }" class="link-arrow">Découvrir le salon <span class="arrow" aria-hidden="true">→</span></RouterLink>
      </div>
      <ul class="values">
        <li v-for="(v, i) in values" :key="v.title" v-reveal="i * 90">
          <h3>{{ v.title }}</h3>
          <p>{{ v.text }}</p>
        </li>
      </ul>
    </div>
  </section>
</template>

<style scoped>
.grid { display: grid; gap: 3rem; }
.statement { display: grid; gap: 1.4rem; align-content: start; }
.values { display: grid; border-top: 1px solid var(--line-strong); align-content: start; }
.values li { padding-block: 1.6rem; border-bottom: 1px solid var(--line-strong); display: grid; gap: 0.5rem; }
.values p { color: var(--muted); }
@media (min-width: 900px) { .grid { grid-template-columns: 1.1fr 1fr; gap: 6rem; } .statement { position: sticky; top: calc(var(--header-h) + 2rem); } }
</style>
