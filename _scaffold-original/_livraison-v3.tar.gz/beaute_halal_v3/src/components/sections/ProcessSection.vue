<script setup>
import { process } from '@/data/editorial'
import { pad2 } from '@/utils/format'
</script>

<template>
  <section class="section">
    <div class="container">
      <header class="head" v-reveal>
        <p class="eyebrow">Comment ça marche</p>
        <h2>Votre demande en <em>quatre temps</em></h2>
      </header>
      <ol class="steps">
        <li v-for="(s, i) in process" :key="s.title" v-reveal="i * 90">
          <span class="numeral">{{ pad2(i + 1) }}</span>
          <h3>{{ s.title }}</h3>
          <p>{{ s.text }}</p>
        </li>
      </ol>
    </div>
  </section>
</template>

<style scoped>
.head { display: grid; gap: 1rem; margin-bottom: 3rem; }
.steps { display: grid; gap: 2rem; counter-reset: s; }
.steps li { display: grid; gap: 0.6rem; padding-top: 1.4rem; border-top: 1.5px solid var(--ink); }
.numeral { font-size: 3.2rem; }
.steps p { color: var(--muted); }
@media (min-width: 640px) { .steps { grid-template-columns: repeat(2, 1fr); gap: 2.5rem 2rem; } }
@media (min-width: 1000px) { .steps { grid-template-columns: repeat(4, 1fr); } .steps li:nth-child(even) { margin-top: 2.5rem; } }
</style>
